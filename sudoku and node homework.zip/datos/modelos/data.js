const fs=require('fs');
//vectores
listaCursos=[];
listaUsuarios=[];
listaRegistro=[];

const crearUsuario=(usuario)=>{
	let usu={
		nombre:usuario.nombre,
		edad:usuario.cedula,
		
	};
	
	listaUsuarios.push(usu);
	console.log(listaUsuarios);
	let datosU=JSON.stringify(listaUsuarios);
	fs.writeFile('Listadousuario.json',datosU,(err)=>{
		if(err)throw(err);
		console.log('Listado de usuarios creado con exito');
	})
	}
module.exports = crearUsuario;