
listaCursos=[];
listaEstudiante=[];
listaDocentes=[];
const fs=require('fs');
const express = require("express");
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
let estudiante = {
 nombre:'Jose',
 apellido: 'Casierra',
 sexo:'M'
};
let estudiante1 = {
  nombre:'Lorena',
  apellido: 'Lopez',
  sexo: 'F'
 };
 let estudiante2 = {
  nombre:'Jose Andres',
  apellido: 'Fernandez',
  sexo: 'M'
  
 };
 let estudiante3 = {
  nombre:'Maria',
  apellido: 'Ramirez',
  
 };

 let curso1 ={
   curso: 'Programacion web',
   horas:'intensidad 32 horas'

 }
 let curso2 ={
  curso: 'Programacion con Python',
  horas:'intensidad 42 horas'

}
let docente1 = {
  materia:'analisis numerico',
  nombre:'Lorena',
  apellido: 'Lopez',
  sexo: 'F'
 };
 let docente2 = {
  materia:'calculo',
  nombre:'Jose Andres',
  apellido: 'Fernandez',
  sexo: 'M'
  
 };
 let docente3 = {
  materia:'Programacion orientada a objetos',
  nombre:'Maria',
  apellido: 'Ramirez',
  sexo: 'F'
 };
//creandp estudiantes
listaEstudiante.push(estudiante);
listaEstudiante.push(estudiante1);
listaEstudiante.push(estudiante2);
listaEstudiante.push(estudiante3);
//creando cursos
listaCursos.push(curso1);
listaCursos.push(curso2);
//creando docentes
listaDocentes.push(docente1);
listaDocentes.push(docente2);
listaDocentes.push(docente3);
let datosU=JSON.stringify(listaEstudiante);
fs.writeFile('ListadoEstudiante.json',datosU,(err)=>{
  if(err)throw(err);
  console.log('Registro realizado con Exito');
})


app.get('/estudiante', function (req, res) {
console.log(estudiante+" "+estudiante1+" "+estudiante2+" "+estudiante3)
res.send(listaEstudiante)
});
app.post('/estudiante', function (req, res) {
 
 res.send(listaEstudiante);

});
//agregar y mostrar materias
app.get('/materia', function (req, res) {
  
  res.send(listaCursos)
  });
  app.post('/materia', function (req, res) {
   
   res.send(listaCursos);
   
  });
  //para docentes
  app.get('/docente', function (req, res) {
  
    res.send(listaDocentes)
    });
    app.post('/docente', function (req, res) {
     
     res.send(listaDocentes);
     
    
    });
app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});